{
    "name": "Book Shop",
    "author": "IdeaCode Academy",
    "license": "LGPL-3",
    "depends": ["base", "web","contacts"],
    "data": [
        "security/ir.model.access.csv",

        "views/res_partner.xml",
        "views/ica_book_category.xml",
        "views/ica_books.xml",
        "views/menus.xml",
    ]
}
